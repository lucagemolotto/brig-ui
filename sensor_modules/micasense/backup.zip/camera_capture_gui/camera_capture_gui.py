#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import subprocess
import sys
import webbrowser
from pathlib import Path
from tkinter import Canvas, E, N, S, StringVar, Tk, W, ttk
from typing import Optional

LAUNCH_SCRIPT_PATH = Path("../main.py").absolute()
CAPTURE_SCRIPT = Path("../camera_capture/camera_capture.py").absolute()


class Window(Tk):
    CAPTURE_RUNNING_TEXT = "Cattura autonoma in esecuzione"
    CAPTURE_NOT_RUNNING_TEXT = "Cattura autonoma non in esecuzione"

    timer_capture_label_text: StringVar
    # timer_capture_icon: Canvas
    timer_capture_button_text: StringVar
    capture_process: Optional[subprocess.Popen] = None

    def run(self):
        self.title("UNIUD Micasense control panel")
        mainframe = ttk.Frame(self, padding="3 3 3 3")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.timer_capture_label_text = StringVar()
        self.timer_capture_label_text.set(self.CAPTURE_NOT_RUNNING_TEXT)
        timer_capture_label = ttk.Label(
            mainframe, textvariable=self.timer_capture_label_text
        )
        timer_capture_label.grid(column=0, row=0)

        self.timer_capture_button_text = StringVar()
        self.timer_capture_button_text.set("Avvia")
        timer_capture_button = ttk.Button(
            mainframe,
            textvariable=self.timer_capture_button_text,
            command=self.toggle_capture,
        )
        timer_capture_button.grid(column=0, row=1)

        ttk.Separator(mainframe, orient="vertical").grid(
            column=1, row=1, ipady=20, padx=10, pady=10
        )

        ttk.Label(mainframe, text="Avvia la live view (apre un browser)").grid(
            column=2, row=0
        )
        ttk.Button(mainframe, text="Apri live view", command=self.open_live_view).grid(
            column=2, row=1
        )

        for child in mainframe.winfo_children():
            child.grid_configure(padx=5, pady=5)

        # self.bind("<Return>", on_return)

        self.check_capture_process()
        self.mainloop()

        self._terminate_capture(10)

    def check_capture_process(self) -> None:
        # Check if the process is still alive.
        if self.capture_process:
            if self.capture_process.poll() is not None:
                # Process dies, remove it.
                self.capture_process = None

        if self.capture_process:
            self.timer_capture_label_text.set(self.CAPTURE_RUNNING_TEXT)
            self.timer_capture_button_text.set("STOP")
        else:
            self.timer_capture_label_text.set(self.CAPTURE_NOT_RUNNING_TEXT)
            self.timer_capture_button_text.set("Avvia")
            # self.timer_capture_icon.add_circle

        self.after(100, self.check_capture_process)

    def toggle_capture(self, *args) -> None:
        if self.capture_process:
            self._terminate_capture(3)

            self.capture_process = None
        else:
            self.capture_process = subprocess.Popen(
                [sys.executable, str(CAPTURE_SCRIPT)]
            )

    def _terminate_capture(self, timeout=1) -> None:
        if self.capture_process and self.capture_process.poll() is None:
            self.capture_process.terminate()
            try:
                self.capture_process.wait(timeout)
            except subprocess.TimeoutExpired:
                self.capture_process.kill()

    def open_live_view(self, *args) -> None:
        webbrowser.open("http://192.168.1.83")
        webbrowser.open("http://192.168.2.83")


def main():
    root = Window()
    root.run()


if __name__ == "__main__":
    main()
